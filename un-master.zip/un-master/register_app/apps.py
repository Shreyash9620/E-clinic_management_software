from django.apps import AppConfig


class RegisterAppConfig(AppConfig):
    name = 'register_app'
